/*****************************************************************************
 Yihsiang Liow
 Copyright
 ****************************************************************************/
#include "Image.h"
#include "Color.h"

//char TextImage::fontfamily[100] = "arial.ttf";

//int TextImage::fontsize = 12;

//Color TextImage::color = WHITE;

